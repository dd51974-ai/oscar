default_app_config = 'oscar.apps.communication.apps.CommunicationConfig'
