default_app_config = 'oscar.apps.voucher.apps.VoucherConfig'
