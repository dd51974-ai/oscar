default_app_config = 'oscar.apps.partner.apps.PartnerConfig'
