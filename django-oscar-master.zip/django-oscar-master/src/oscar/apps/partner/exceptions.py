class ImportingError(Exception):
    pass


class InvalidStockAdjustment(Exception):
    pass
