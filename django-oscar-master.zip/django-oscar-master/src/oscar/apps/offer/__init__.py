default_app_config = 'oscar.apps.offer.apps.OfferConfig'
