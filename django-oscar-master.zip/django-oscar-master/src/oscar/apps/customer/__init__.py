default_app_config = 'oscar.apps.customer.apps.CustomerConfig'
