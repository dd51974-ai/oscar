default_app_config = (
    'oscar.apps.dashboard.reports.apps.ReportsDashboardConfig')
