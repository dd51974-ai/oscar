default_app_config = (
    'oscar.apps.dashboard.shipping.apps.ShippingDashboardConfig')
